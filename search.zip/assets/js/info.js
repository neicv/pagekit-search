$(function () {

    new Vue({
        el: '#info',
        data: function(){ return {};}
    });

});


