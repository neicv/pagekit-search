<h2 class="uk-margin-remove">{{ 'About Search' | trans }}</h2>
<h3>Version 0.1.7</h3>
<div>Created by <a href="http://pagekit.friendly-it.ru" title="Friendly IT" target="_search">Friendly IT, LLC</a></div>
<div>Email: <a href="mailto:info@friendly-it.ru" title="Contact Email" target="_search">info@friendly-it.ru</a></div>
<div>Github: <a href="https://github.com/neicv/pagekit-search" title="Pagekit Search on GitHub" target="_search">pagekit-search</a>
</div>
<div>Changelog: <a href="https://github.com/neicv/pagekit-search/blob/master/CHANGELOG.md" target="_search" title="Pagekit Search Changelog on GitHub">CHANGELOG.md</a>
</div>
