<h2 class="uk-margin-remove">{{ 'About Search' | trans }}</h2>
<h3>Version 0.1.7</h3>
<div>Created by <a href="http://pagekit.friendly-it.ru" title="Friendly IT" target="_search">Friendly IT, LLC</a></div>
<div>Email: <a href="mailto:info@friendly-it.ru" title="Contact Email" target="_search">info@friendly-it.ru</a></div>
<div>Github: <a href="https://github.com/neicv/pagekit-search" title="Pagekit Search on GitHub" target="_search">pagekit-search</a></div>
<div>Changelog: <a href="https://github.com/neicv/pagekit-search/blob/master/CHANGELOG.md" target="_search" title="Pagekit Search Changelog on GitHub">CHANGELOG.md</a></div>
<div>Last or Old Releases you can find: <a href="https://pagekit.friendly-it.ru/ext-search" target="_search" title="Pagekit Search releases">pagekit.friendly-it.ru</a></div>

<hr>

<div>You can provide donate and support for the project: <a href="https://paypal.me/neicv" target="_search" title="PayPal is one of the most widely used payment processors.">via PayPal</a></div>

