# Pagekit Search

Friendly IT Search for Pagekit extension enables you to make search request on "Blog", "Page",
and You can use a Self Search Plugin to search through the database of your Pagekit site. 

It contains "Search Widget".

![image](http://pagekit.friendly-it.ru/storage/img/searchscreenshot.jpg)

## Installation

Please install Search via the built-in Marketplace in your Pagekit Installation.

![image](http://pagekit.friendly-it.ru/storage/img/marketplace1.jpg)

The extension and all its dependancies will be installed automatically.

## Usage
If you wanna make "search page" - go to `Site -> Add new Page -> Link` in the Pagekit admin area.
And make link to "/search".

Or / And u can use "Search widget" 

## Issues and feature requests

Please use the [issues section](https://github.com/neicv/pagekit-search/issues) to file any bugs or feature requests.
